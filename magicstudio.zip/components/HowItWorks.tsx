import React from 'react';
import { STEPS } from '../constants';
import { ArrowRight } from 'lucide-react';

const HowItWorks: React.FC = () => {
  return (
    <section id="how-it-works" className="py-24 bg-black relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8">
          {STEPS.map((step, idx) => (
            <div key={idx} className="relative flex flex-col p-6 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors group">
              <div className="flex items-center justify-between mb-6">
                <div className="w-16 h-16 rounded-xl bg-black border border-white/10 flex items-center justify-center shadow-lg group-hover:border-cyan-500/50 transition-colors">
                  {step.icon}
                </div>
                <span className="text-5xl font-serif text-white/5 font-bold absolute top-4 right-6">{idx + 1}</span>
              </div>
              
              <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{step.description}</p>
              
              {idx < 2 && (
                 <div className="hidden md:block absolute top-1/2 -right-4 -translate-y-1/2 z-10 text-white/20">
                    <ArrowRight size={24} />
                 </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;