import React from 'react';
import { motion } from 'framer-motion';
import ComparisonSlider from './ComparisonSlider';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen pt-32 pb-20 overflow-hidden bg-black flex flex-col items-center justify-center">
      
      {/* Background Ambience */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-blue-900/10 rounded-full blur-[120px] -z-10 opacity-60 pointer-events-none" />
      
      <div className="max-w-[90rem] mx-auto px-6 w-full flex flex-col items-center relative z-10">
        
        {/* Text Content Group */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center w-full mb-12 space-y-6"
        >
          {/* 1. Title - Two Lines with Spacing */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl xl:text-8xl font-bold tracking-tight font-serif leading-[1.1]">
            Transforme Fotos Comuns em
            <span className="block mt-2 md:mt-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500">
              Imagens Profissionais
            </span>
          </h1>
          
          {/* 2. Subtitle */}
          <p className="text-base md:text-lg lg:text-xl text-gray-400 font-light max-w-3xl mx-auto">
            Envie sua foto. Nós transformamos em uma imagem pronta para vender.
          </p>

          {/* 3. Niche List */}
          <p className="text-base md:text-lg lg:text-xl text-white font-medium">
            Moda, Produtos, Restaurantes e Bebidas.
          </p>
        </motion.div>

        {/* 4. Hero Visual - Full Width Cinematic Slider */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2, ease: "circOut" }}
          className="relative w-full max-w-6xl mx-auto group"
        >
            {/* Decorative Glow behind image */}
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 rounded-3xl blur opacity-20 group-hover:opacity-40 transition-opacity duration-1000 animate-pulse-slow"></div>
            
            <div className="relative rounded-3xl overflow-hidden shadow-2xl bg-gray-900 border border-white/10">
              <div className="hero-comparison-wrapper">
                 <ComparisonSlider 
                    // Certifique-se de criar a pasta public/assets e salvar as imagens com esses nomes
                    beforeImage="/assets/menina-antes.jpg"
                    afterImage="/assets/menina-depois.jpg"
                    alt="Transformação Profissional"
                    aspectRatio="aspect-[4/3] md:aspect-[21/9]" 
                 />
              </div>
            </div>
            
            <div className="absolute -bottom-10 left-0 right-0 text-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
               <span className="text-xs font-mono text-cyan-500 tracking-[0.2em] uppercase">Arraste para ver a mágica</span>
            </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;