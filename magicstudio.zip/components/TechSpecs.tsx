import React from 'react';
import { ScanFace, Image, Users, TrendingUp } from 'lucide-react';

const TechSpecs: React.FC = () => {
  return (
    <section className="py-24 bg-zinc-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-8 font-serif">
            Tratamento de Imagem Personalizado
          </h2>
          
          <p className="text-lg md:text-xl text-gray-300">
            Cada imagem é analisada e ajustada uma por uma, <br/>
            <span className="text-white font-semibold">com atenção aos detalhes.</span>
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-2xl bg-gray-900/50 border border-white/5 hover:border-cyan-500/30 transition-all group">
              <ScanFace className="text-cyan-400 mb-4 group-hover:scale-110 transition-transform" size={32} />
              <h4 className="text-white font-bold mb-2 text-lg">Reconstrução Inteligente</h4>
              <p className="text-sm text-gray-400 leading-relaxed">Aprimoramos luz, nitidez e detalhes mantendo a essência do produto.</p>
            </div>
            
            <div className="p-6 rounded-2xl bg-gray-900/50 border border-white/5 hover:border-purple-500/30 transition-all group">
              <Image className="text-purple-400 mb-4 group-hover:scale-110 transition-transform" size={32} />
              <h4 className="text-white font-bold mb-2 text-lg">Ambientação Realista</h4>
              <p className="text-sm text-gray-400 leading-relaxed">Inserimos seu produto em cenários estratégicos e profissionais.</p>
            </div>
            
            <div className="p-6 rounded-2xl bg-gray-900/50 border border-white/5 hover:border-pink-500/30 transition-all group">
              <Users className="text-pink-400 mb-4 group-hover:scale-110 transition-transform" size={32} />
              <h4 className="text-white font-bold mb-2 text-lg">Aplicação em Modelo</h4>
              <p className="text-sm text-gray-400 leading-relaxed">Criamos apresentações naturais e proporcionais em modelos humanos.</p>
            </div>
            
            <div className="p-6 rounded-2xl bg-gray-900/50 border border-white/5 hover:border-green-500/30 transition-all group">
              <TrendingUp className="text-green-400 mb-4 group-hover:scale-110 transition-transform" size={32} />
              <h4 className="text-white font-bold mb-2 text-lg">Otimização de Conversão</h4>
              <p className="text-sm text-gray-400 leading-relaxed">Cada imagem é ajustada para aumentar percepção de valor e impacto visual.</p>
            </div>
        </div>
      </div>
    </section>
  );
};

export default TechSpecs;