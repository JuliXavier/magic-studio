import React from 'react';
import ComparisonSlider from './ComparisonSlider';
import { TRANSFORMATIONS } from '../constants';

const Gallery: React.FC = () => {
  return (
    <section id="gallery" className="py-24 bg-black relative overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-1/2 left-0 w-1/3 h-1/2 bg-blue-900/10 blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-16 text-center">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-4 font-serif">Resultados Reais</h2>
            <p className="text-gray-400">Exemplos de transformações em diferentes nichos.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {TRANSFORMATIONS.map((item, idx) => (
            <div key={idx} className="flex flex-col gap-6">
              <div className="relative group rounded-2xl overflow-hidden border border-white/10 bg-gray-900/50 p-2 hover:border-cyan-500/30 transition-colors duration-500">
                 <div className="gallery-item-wrapper shadow-2xl">
                    <ComparisonSlider 
                        beforeImage={item.before}
                        afterImage={item.after}
                        alt={item.label}
                        aspectRatio="aspect-[3/4]"
                    />
                 </div>
              </div>
              <div className="text-center">
                <h3 className="text-xl font-bold text-white">{item.label}</h3>
                <p className="text-gray-500 text-sm mt-1">Processamento IA + Ajuste Manual</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;