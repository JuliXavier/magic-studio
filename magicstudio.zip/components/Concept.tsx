import React from 'react';
import { CheckCircle2, Wand2, XCircle } from 'lucide-react';

const Concept: React.FC = () => {
  const capabilities = [
    "Melhoramos luz, cor e qualidade",
    "Aplicamos em modelos ou cenários realistas",
    "Deixamos seu produto mais bonito e valorizado"
  ];

  return (
    <section className="bg-black relative z-10">
      
      {/* SECTION: THE PROBLEM */}
      <div className="py-24 border-b border-white/5 bg-gradient-to-b from-black to-zinc-950">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">
            Seu produto pode ser incrível. <br/>
            <span className="text-gray-500">Mas se a foto não mostra isso, ninguém percebe.</span>
          </h2>
          <p className="text-xl text-gray-400 leading-relaxed font-light">
            <strong className="text-white block mt-2">A imagem certa faz toda diferença.</strong>
          </p>
        </div>
      </div>

      {/* SECTION: THE SOLUTION */}
      <div className="py-24">
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
          
          <div>
            <span className="text-cyan-500 font-bold tracking-wider uppercase text-xs mb-2 block">A Solução</span>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6 leading-tight">
              Transformamos sua Foto <br/>
              em Imagem Profissional
            </h2>
            <div className="space-y-6 text-gray-400 text-lg">
              <p>
                Você envia a foto do seu produto.
              </p>
              <p className="text-white font-medium text-xl">
                Nós deixamos com aparência de marca grande.
              </p>
            </div>
            
            <div className="mt-8 pt-8 border-t border-white/10">
               <div className="flex flex-col gap-4">
                 {capabilities.map((cap, idx) => (
                   <div key={idx} className="flex items-start gap-3 text-lg text-gray-300">
                     <CheckCircle2 size={24} className="text-cyan-500 shrink-0 mt-0.5" />
                     {cap}
                   </div>
                 ))}
                 
                 <div className="flex items-start gap-3 text-lg text-gray-400">
                    <XCircle size={24} className="text-gray-600 shrink-0 mt-0.5" />
                    <span>Sem estúdio caro.</span>
                 </div>
                 <div className="flex items-start gap-3 text-lg text-gray-400">
                    <XCircle size={24} className="text-gray-600 shrink-0 mt-0.5" />
                    <span>Sem produção complicada.</span>
                 </div>
               </div>
            </div>
          </div>

          <div className="relative group">
             {/* Tech Frame Container */}
             <div className="relative rounded-lg overflow-hidden border border-white/10 bg-gray-900 shadow-[0_0_50px_rgba(0,0,0,0.5)] h-[500px]">
                
                {/* SPLIT VIEW IMPLEMENTATION */}
                <div className="absolute inset-0 grid grid-cols-2">
                    
                    {/* Left: Input (Flat Lay Product) */}
                    <div className="relative bg-[#e5e5e5] overflow-hidden">
                        <img 
                          src="https://plus.unsplash.com/premium_photo-1673356301535-21a5d588506d?q=80&w=800&auto=format&fit=crop" 
                          alt="Flat Lay Input" 
                          className="w-full h-full object-cover object-center opacity-90 mix-blend-multiply scale-90"
                        />
                        <div className="absolute top-4 left-4 bg-black/10 backdrop-blur-md px-3 py-1.5 rounded text-[10px] font-bold text-gray-600 tracking-widest border border-black/5">
                            ORIGINAL
                        </div>
                        {/* Subtle Grid on Left */}
                        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00000008_1px,transparent_1px),linear-gradient(to_bottom,#00000008_1px,transparent_1px)] bg-[size:24px_24px]"></div>
                    </div>

                    {/* Right: Output (Model Wearing Product) */}
                    <div className="relative overflow-hidden">
                         <img 
                          src="https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=800&auto=format&fit=crop" 
                          alt="AI Model Output" 
                          className="w-full h-full object-cover object-top"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                         <div className="absolute top-4 right-4 bg-cyan-500/90 backdrop-blur-md px-3 py-1.5 rounded text-[10px] font-bold text-white tracking-widest shadow-lg shadow-cyan-500/20 border border-cyan-400/50">
                            AI GENERATED
                        </div>
                    </div>

                </div>

                {/* Tech Overlays (Central Analysis Interface) */}
                <div className="absolute inset-0 pointer-events-none">
                   
                   {/* Center Line Divider */}
                   <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-white/20 z-10"></div>
                   
                   {/* Central Scanner Circle */}
                   <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border border-cyan-500/30 rounded-full flex items-center justify-center">
                       <div className="w-[90%] h-[90%] border border-white/10 rounded-full animate-[spin_10s_linear_infinite]"></div>
                       <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent animate-pulse"></div>
                   </div>

                   {/* Floating Analysis Data Points */}
                   <div className="absolute top-[40%] left-[45%] flex items-center gap-2">
                       <div className="w-2 h-2 bg-cyan-400 rounded-full shadow-[0_0_10px_cyan]"></div>
                       <div className="h-[1px] w-12 bg-cyan-500/50"></div>
                       <div className="bg-black/60 backdrop-blur text-[10px] text-cyan-300 px-2 py-0.5 border-l border-cyan-500">MAPPING TEXTURE</div>
                   </div>

                   <div className="absolute bottom-[30%] right-[45%] flex items-center gap-2 flex-row-reverse">
                       <div className="w-2 h-2 bg-purple-400 rounded-full shadow-[0_0_10px_purple]"></div>
                       <div className="h-[1px] w-12 bg-purple-500/50"></div>
                       <div className="bg-black/60 backdrop-blur text-[10px] text-purple-300 px-2 py-0.5 border-r border-purple-500">GENERATING POSE</div>
                   </div>

                   {/* Bottom Status Card */}
                   <div className="absolute bottom-6 left-6 right-6">
                      <div className="bg-black/60 backdrop-blur-md border border-white/10 p-4 rounded-xl flex items-center justify-between shadow-2xl">
                         <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center">
                               <Wand2 size={18} className="text-cyan-400" />
                            </div>
                            <div>
                               <div className="text-[10px] uppercase tracking-wider text-gray-400 mb-0.5">Processamento</div>
                               <div className="text-sm text-white font-bold flex items-center gap-2">
                                  TRANSFORMAÇÃO COMPLETA
                               </div>
                            </div>
                         </div>
                         
                         <div className="flex items-center gap-2">
                            <span className="relative flex h-3 w-3">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
                            </span>
                         </div>
                      </div>
                   </div>
                </div>
             </div>
             
             {/* Background Ambience Glow */}
             <div className="absolute -top-10 -right-10 w-64 h-64 bg-cyan-500/5 rounded-full blur-[80px] pointer-events-none"></div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Concept;