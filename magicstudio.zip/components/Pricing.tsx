import React from 'react';
import { Check } from 'lucide-react';
import Button from './Button';
import { PRICING } from '../constants';

const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 font-serif">Planos Simples</h2>
          <p className="text-gray-400">Escolha o pacote ideal para o volume do seu negócio.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 items-start">
          {PRICING.map((plan) => (
            <div 
              key={plan.id} 
              className={`relative rounded-3xl p-8 border transition-all duration-300 ${plan.recommended ? 'bg-gray-900/80 border-cyan-500 shadow-[0_0_50px_rgba(6,182,212,0.1)] scale-105 z-10' : 'bg-gray-900/30 border-white/10 hover:bg-gray-900/50'}`}
            >
              {plan.recommended && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold px-4 py-1 rounded-full uppercase tracking-wider shadow-lg">
                  Mais Popular
                </div>
              )}
              
              <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
              <p className="text-gray-400 text-sm mb-6 h-10">{plan.description}</p>
              
              <div className="flex items-baseline gap-1 mb-8">
                <span className="text-4xl font-bold text-white">{plan.price}</span>
                <span className="text-gray-500">/mês</span>
              </div>

              <div className="space-y-4 mb-8">
                {plan.features.map((feat, idx) => (
                  <div key={idx} className="flex items-center gap-3 text-sm text-gray-300">
                    <div className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center shrink-0">
                        <Check size={12} className="text-cyan-400" />
                    </div>
                    {feat}
                  </div>
                ))}
              </div>

              <Button 
                variant={plan.recommended ? 'secondary' : 'outline'} 
                className="w-full"
              >
                Escolher {plan.name}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;