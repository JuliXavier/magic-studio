import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ChevronsLeftRight } from 'lucide-react';

interface ComparisonSliderProps {
  beforeImage: string;
  afterImage: string; // If same URL, we apply CSS filters to 'before' to simulate
  alt: string;
  aspectRatio?: string; // e.g., 'aspect-[4/3]'
  overlayText?: boolean;
}

const ComparisonSlider: React.FC<ComparisonSliderProps> = ({ 
  beforeImage, 
  afterImage, 
  alt,
  aspectRatio = 'aspect-[4/3]',
  overlayText = true
}) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = useCallback((clientX: number) => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const x = clientX - rect.left;
      const width = rect.width;
      const percentage = Math.max(0, Math.min(100, (x / width) * 100));
      setSliderPosition(percentage);
    }
  }, []);

  const onMouseMove = (e: React.MouseEvent) => {
    if (isDragging) handleMove(e.clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (isDragging) handleMove(e.touches[0].clientX);
  };

  const onMouseDown = () => setIsDragging(true);
  const onTouchStart = () => setIsDragging(true);
  const onMouseUp = () => setIsDragging(false);

  useEffect(() => {
    const handleGlobalMouseUp = () => setIsDragging(false);
    window.addEventListener('mouseup', handleGlobalMouseUp);
    window.addEventListener('touchend', handleGlobalMouseUp);
    return () => {
      window.removeEventListener('mouseup', handleGlobalMouseUp);
      window.removeEventListener('touchend', handleGlobalMouseUp);
    };
  }, []);

  return (
    <div 
      className={`relative w-full ${aspectRatio} overflow-hidden rounded-2xl select-none group cursor-col-resize shadow-2xl shadow-blue-900/10 border border-white/10`}
      ref={containerRef}
      onMouseMove={onMouseMove}
      onTouchMove={onTouchMove}
      onMouseDown={onMouseDown}
      onTouchStart={onTouchStart}
    >
      {/* After Image (Background - Full) */}
      <img 
        src={afterImage} 
        alt={`After ${alt}`} 
        className="absolute top-0 left-0 w-full h-full object-cover pointer-events-none"
        draggable={false}
      />
      
      {overlayText && (
         <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold tracking-wider text-cyan-400 z-10 border border-cyan-500/30">
           DEPOIS
         </div>
      )}

      {/* Before Image (Clipped) */}
      <div 
        className="absolute top-0 left-0 h-full w-full overflow-hidden pointer-events-none"
        style={{ width: `${sliderPosition}%` }}
      >
        <img 
          src={beforeImage} 
          alt={`Before ${alt}`} 
          className="absolute top-0 left-0 h-full max-w-none object-cover" 
          style={{ width: containerRef.current?.offsetWidth || '100%' }} // Keep aspect ratio correct by forcing width
          draggable={false}
        />
        {/* Dark overlay on Before image to emphasize the difference if images are raw */}
        <div className="absolute inset-0 bg-black/10 pointer-events-none mix-blend-multiply"></div>
        
        {overlayText && (
          <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold tracking-wider text-white/70 z-10 border border-white/10">
            ANTES
          </div>
        )}
      </div>

      {/* Slider Line with Handle */}
      <div 
        className="absolute top-0 bottom-0 w-0.5 bg-white cursor-col-resize z-20 shadow-[0_0_15px_rgba(255,255,255,0.5)]"
        style={{ left: `${sliderPosition}%` }}
      >
        {/* Central Handle Button */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-white rounded-full shadow-[0_4px_20px_rgba(0,0,0,0.5)] flex items-center justify-center z-30 transform transition-transform duration-200 hover:scale-110">
           <ChevronsLeftRight className="text-gray-900 w-6 h-6" />
        </div>
      </div>
    </div>
  );
};

export default ComparisonSlider;