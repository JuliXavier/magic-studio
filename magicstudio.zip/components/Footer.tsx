import React from 'react';
import { Sparkles } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-white/10 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col items-center text-center mb-16">
            <div className="flex items-center gap-2 mb-6">
               <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center">
                  <Sparkles size={18} className="text-white fill-white" />
               </div>
               <span className="text-xl font-bold tracking-tight text-white font-sans">
                  Magic<span className="text-cyan-400">Studio</span>
               </span>
            </div>
            <p className="text-gray-400 max-w-sm">
              Elevando o padrão visual de e-commerces e criadores de conteúdo com inteligência artificial de ponta.
            </p>
        </div>

        <div className="border-t border-white/5 pt-8 text-center text-xs text-gray-600">
          <p>&copy; {new Date().getFullYear()} MagicStudio. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;