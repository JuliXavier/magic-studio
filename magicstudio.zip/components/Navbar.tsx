import React, { useState, useEffect } from 'react';
import { Sparkles } from 'lucide-react';
import Button from './Button';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b ${isScrolled ? 'bg-black/80 backdrop-blur-lg border-white/10 py-3' : 'bg-transparent border-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        
        {/* Logo */}
        <div className="flex items-center gap-2 cursor-pointer group">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Sparkles size={18} className="text-white fill-white" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white font-sans">
            Magic<span className="text-cyan-400">Studio</span>
          </span>
        </div>

        {/* CTA Button - Top Right Corner */}
        <div>
           <Button 
             variant="secondary" 
             size="sm" 
             className="hidden sm:inline-flex shadow-[0_0_20px_rgba(6,182,212,0.3)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)] font-semibold"
           >
             Quero transformar minhas fotos
           </Button>
           
           {/* Mobile Button Variant (Icon or shorter text) */}
           <Button 
             variant="secondary" 
             size="sm" 
             className="sm:hidden text-xs px-4 py-2 font-semibold"
           >
             Transformar
           </Button>
        </div>

      </div>
    </nav>
  );
};

export default Navbar;