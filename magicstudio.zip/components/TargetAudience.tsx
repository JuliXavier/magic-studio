import React from 'react';
import { NICHES } from '../constants';
import { ArrowRight } from 'lucide-react';

const TargetAudience: React.FC = () => {
  return (
    <section className="py-24 bg-black border-t border-white/5">
       <div className="max-w-7xl mx-auto px-6">
          <div className="mb-16 text-center md:text-left">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-4 font-serif">Se você vende visual, <br/>você precisa disso.</h2>
            <p className="text-gray-400 text-lg">Soluções especializadas para cada nicho de mercado.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {NICHES.map((niche, idx) => (
              <div 
                key={idx} 
                className="group relative overflow-hidden rounded-2xl bg-gray-900 border border-white/5 hover:border-cyan-500/30 transition-all duration-300"
              >
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent z-10"></div>
                <img src={niche.image} alt={niche.title} className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:scale-105 transition-transform duration-700" />
                
                <div className="relative z-20 p-8 h-full min-h-[280px] flex flex-col justify-end">
                  <div className="mb-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                    {niche.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">{niche.title}</h3>
                  <p className="text-gray-400 text-sm opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                    {niche.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-16 text-center">
             <p className="text-2xl font-serif text-white mb-2">"A forma como seu produto é visto define o quanto ele vale."</p>
          </div>
       </div>
    </section>
  );
};

export default TargetAudience;